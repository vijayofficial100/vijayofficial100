package onetohundredthreadpool;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Main {


    public static void main(String[] args) {
        ExecutorService executorService = Executors.newFixedThreadPool(8);

        for (int i = 1; i <= 1000; ++i) {
            if (i == 501) {
                System.out.println("Wait");
            }
            NumberPrinter np = new NumberPrinter(i);
            executorService.execute(np);
        }
    }
}
