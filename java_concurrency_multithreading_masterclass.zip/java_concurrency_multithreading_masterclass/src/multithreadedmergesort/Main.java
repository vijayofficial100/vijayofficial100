package multithreadedmergesort;

import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class Main {

    public static void main(String[] args) throws ExecutionException, InterruptedException {
        List<Integer> array = List.of(38, 27, 43, 3, 9, 82, 10);
        System.out.println("Unsorted array:");

        ExecutorService executor = Executors.newFixedThreadPool(1);
        Sorter sortingTask = new Sorter(array);

        Future<List<Integer>> sortedArrayFuture = executor.submit(sortingTask);

        List<Integer> sortedArray = sortedArrayFuture.get();

        System.out.println("Sorted array: ");
    }

    public static void printArray(int[] array) {
        for (int num : array) {
            System.out.print(num + " ");
        }
        System.out.println();
    }
}
