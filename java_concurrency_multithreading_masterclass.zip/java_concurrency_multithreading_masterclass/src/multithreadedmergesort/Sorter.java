package multithreadedmergesort;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class Sorter implements Callable<List<Integer>> {
    List<Integer> arrayToSort;

    public Sorter(List<Integer> arrayToSort) {
        this.arrayToSort = arrayToSort;
    }

    @Override
    public List<Integer> call() throws Exception {
        System.out.println("Sorting array: " + arrayToSort + " in thread " + Thread.currentThread().getName());
        if (arrayToSort.size() <= 1) {
            return arrayToSort;
        }

        // Divide array into two halves
        int mid = arrayToSort.size() / 2;
        List<Integer> left = arrayToSort.subList(0, mid);
        List<Integer> right = arrayToSort.subList(mid, arrayToSort.size());

        Sorter leftSorter = new Sorter(left); // task to sort the left array
        Sorter rightSorter = new Sorter(right); // task to sort the right array

        ExecutorService executor = Executors.newFixedThreadPool(2);
        Future<List<Integer>> leftSortedArrayFuture = executor.submit(leftSorter);
        Future<List<Integer>> rightSortedArrayFuture = executor.submit(rightSorter);

        //Merge
        List<Integer> leftSortedArray = leftSortedArrayFuture.get();
        List<Integer> rightSortedArray = rightSortedArrayFuture.get();

        List<Integer> mergedArray = new ArrayList<>();
        int i = 0, j = 0;
        while (i < leftSortedArray.size() && j < rightSortedArray.size()) {
            if (leftSortedArray.get(i) <= rightSortedArray.get(j)) {
                mergedArray.add(leftSortedArray.get(i));
                i++;
            } else {
                mergedArray.add(rightSortedArray.get(j));
                j++;
            }
        }

        while (i < leftSortedArray.size()) {
            mergedArray.add(leftSortedArray.get(i));
            i++;
        }

        while (j < rightSortedArray.size()) {
            mergedArray.add(rightSortedArray.get(j));
            j++;
        }


        return mergedArray;
    }
}
