package normalprogram;

public class Main {
    public static void main(String[] args) {
        int a = 2;
        int b = 3;
        System.out.println("Hello " + Thread.currentThread().getName());
        add(a, b);
        System.out.println("Hey " + Thread.currentThread().getName());

    }

    public static int add(int a, int b) {
        System.out.println("Hi " + Thread.currentThread().getName());
        return a + b;
    }
}
