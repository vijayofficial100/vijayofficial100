package helloworldofthreads;

public class Main {

    public static void main(String[] args) {
        System.out.println("Hi 1 " + Thread.currentThread().getName());

        // start a new Thread
        HiChildPrinter hcp = new HiChildPrinter();

        Thread t = new Thread(hcp);

        t.start();

        System.out.println("Hi Parent " + Thread.currentThread().getName());
    }
}
