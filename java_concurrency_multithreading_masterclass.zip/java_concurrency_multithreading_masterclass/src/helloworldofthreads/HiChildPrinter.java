package helloworldofthreads;

public class HiChildPrinter implements Runnable {

    @Override
    public void run() {
        System.out.println("Hi Child " + Thread.currentThread().getName());
    }
}
